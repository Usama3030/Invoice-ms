<?php

include('include/header.php');
include('include/topbar.php');
include('include/sidebar.php');

?>
<style>

    .content{
        margin-left: 400px;
    }
    
form {
  max-width: 600px;
}

.mb-3 {
  margin-bottom: 1rem;
}

.form-label {
  font-weight: bold;
}

.form-control {
  width: 100%;
  border: 1px solid #ccc;
}

    </style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Product</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Product form</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
<section class="content">
      <div class="container-fluid">
<form id="insertedkey1" class="row g-3" method="post" action="pages/productadd.php">
      
        <div  class="detail">
             <div class="mb-3">
          <label for="name" class="form-label">Service Name</label>
          <input type="text" name="service" id="name" class="form-control" required>
        </div>
        <div class="mb-3">
        <label for="poneno1" class="form-label">Package</label>
    <input type="text" class="form-control" name="pk" id="poneno1" placeholder="10mb" required>
        </div>
        <div class="mb-3">
            <label for="pcc" class="form-label">Customer price</label>
    <input type="text" class="form-control" name="cp" id="pcc" required>
        </div>
            <div class="mb-3">
          <label for="qn1" class="form-label">Original Price</label>
    <input type="text" class="form-control" name="oq" id="qn1" required>
        </div>

    
      <div class="button">
    <button type="submit" class="btn btn-success">submit</button>
  </div>
          
          
            </div>
                </form>
        </div>
    </section>

    <script>
  // Prevent form submission if any of the input fields are empty
  function preventEmptyFormSubmission() {
    var inputs = document.querySelectorAll("input[required]");
    var isFormValid = true;
    for (var i = 0; i < inputs.length; i++) {
      if (inputs[i].value === "") {
        isFormValid = false;
        break;
      }
    }
    if (!isFormValid) {
      alert("Please fill out all required fields.");
      return false;
    }
  }
  document.getElementById("insertedkey1").addEventListener("submit", preventEmptyFormSubmission);
</script>
