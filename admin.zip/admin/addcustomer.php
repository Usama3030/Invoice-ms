<?php

include('include/header.php');
include('include/topbar.php');
include('include/sidebar.php');

?>
<style>

    .content{
        margin-left: 400px;
    }
    
form {
  max-width: 600px;
}

.mb-3 {
  margin-bottom: 1rem;
}

.form-label {
  font-weight: bold;
}

.form-control {
  width: 100%;
  border: 1px solid #ccc;
}

.btn {
  background-color: #007bff;
  color: white;
  cursor: pointer;
}

.btn-primary {
  color: #fff;
  background-color: #007bff;
  border-color: #007bff;
}
    </style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Customer</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Customer Form</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <section class="content">
      <div class="container-fluid">
<form id="insertedkey1" class="row g-3" method="post" action="pages/customeradd.php">
      
        <div  class="detail">
             <div class="mb-3">
          <label for="name" class="form-label">Customer Name</label>
          <input type="text" name="name" id="name" class="form-control" required>
        </div>
              <div class="mb-3">
          <label for="cid" class="form-label">Customer ID</label>
          <input type="text" name="customerid" id="cid" class="form-control" required>
        </div>
        <div class="mb-3">
          <label for="phone" class="form-label">Phone Number</label>
          <input type="text" name="phone" id="phone" class="form-control" required>
        </div>
        <div class="mb-3">
          <label for="address" class="form-label">Address</label>
          <input type="text" name="address" id="address" class="form-control" placeholder="1234 Main St" required>
        </div>
            <div class="mb-3">
          <label for="note" class="form-label">Message</label>
          <input type="text" name="note" id="note" class="form-control" placeholder="Enter the message">
        </div>

    
      <div class="button">
    <button type="submit" class="btn btn-success">submit</button>
  </div>
          
          
            </div>
                </form>
        </div>
    </section>

    <script>
  // Prevent form submission if any of the input fields are empty
  function preventEmptyFormSubmission() {
    var inputs = document.querySelectorAll("input[required]");
    var isFormValid = true;
    for (var i = 0; i < inputs.length; i++) {
      if (inputs[i].value === "") {
        isFormValid = false;
        break;
      }
    }
    if (!isFormValid) {
      alert("Please fill out all required fields.");
      return false;
    }
  }
  document.getElementById("insertedkey1").addEventListener("submit", preventEmptyFormSubmission);
</script>
